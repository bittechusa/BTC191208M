package oop;

public interface WildAnimal extends Animal,DomesticAnimal{
int a=8;
	public void hunt();
	class A{
		
	}
}
