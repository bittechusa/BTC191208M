package oop;

public interface DomesticAnimal extends Animal{

}
