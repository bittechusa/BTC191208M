package oop;

public class BabyTiger {

}
