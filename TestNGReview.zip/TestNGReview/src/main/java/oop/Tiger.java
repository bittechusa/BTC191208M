package oop;

import org.apache.xmlbeans.impl.xb.xmlschema.BaseAttribute;

public abstract class Tiger extends BabyTiger implements WildAnimal,DomesticAnimal{

	public void eat() {
		// TODO Auto-generated method stub
		
	}
public abstract void te();
	

}
