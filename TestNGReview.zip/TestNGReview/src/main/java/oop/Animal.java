package oop;

public interface Animal {

	public void eat() ;
		
	
}
